###getopt Library

This is used only for the Win32 build.

Used under the terms of the GPL. For license information, see source file headers.
